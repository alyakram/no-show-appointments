Source references:
https://pandas.pydata.org/docs/user_guide/visualization.html
https://stackoverflow.com/questions/52753613/grouping-categorising-ages-column-in-python-pandas
https://stackoverflow.com/questions/46794373/make-a-bar-graph-of-2-variables-based-on-a-dataframe
https://www.statology.org/convert-datetime-to-date-pandas/
https://re-thought.com/how-to-suppress-scientific-notation-in-pandas/
https://www.kaggle.com/getting-started/40799
https://stackoverflow.com/questions/11346283/renaming-column-names-in-pandas